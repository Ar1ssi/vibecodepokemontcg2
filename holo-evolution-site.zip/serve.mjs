import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
const root = path.resolve(process.argv[2]); const port = +process.argv[3] || 8787;
const types = {'.html':'text/html; charset=utf-8','.css':'text/css','.mjs':'text/javascript','.js':'text/javascript','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.json':'application/json'};
http.createServer((req,res)=>{
  let p = decodeURIComponent(new URL(req.url,'http://x').pathname); if (p.endsWith('/')) p+='index.html';
  const f = path.join(root,p);
  if (!f.startsWith(root) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('nf'); }
  res.writeHead(200,{'content-type':types[path.extname(f)]||'application/octet-stream','cache-control':'public, max-age=300'});
  fs.createReadStream(f).pipe(res);
}).listen(port,'0.0.0.0',()=>console.log('serving',root,port));
