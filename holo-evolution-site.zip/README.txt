Holofoil evolution site (static).
  node serve.mjs . 8787
  cloudflared tunnel --url http://localhost:8787   # prints https://<random>.trycloudflare.com
